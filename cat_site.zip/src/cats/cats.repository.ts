import { InjectModel } from '@nestjs/mongoose';
import { Cat } from './cats.schema';
import { Model } from 'mongoose';
import { Injectable } from '@nestjs/common';
import { CatRequestDto } from './dto/cats.request.dto';

@Injectable()
export class CatsRepository {
  constructor(@InjectModel(Cat.name) private readonly catModel: Model<Cat>) {}

  //* 들어온 이메일과 매칭되는 녀석이 있냐 없냐 찾기
  async existsByEmail(email: string): Promise<boolean> {
    const result = await this.catModel.exists({ email }); //* 몽구스 exists( ) 함수의 결괏값으로는 id :any 이 반환되고 값이 없으면 null을 반환
    if (result) return true;
    else return false;
  }

  //* 계정 생성
  async create(cat: CatRequestDto): Promise<Cat> {
    return await this.catModel.create(cat);
  }
}
